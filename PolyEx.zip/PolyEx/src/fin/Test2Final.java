package fin;

public class Test2Final {
	
	final int aa =1010;
	
	public Test2Final() {
		//aa = 100;
	}
	

	public static void main(String[] args) {
		Test2Final tf = new Test2Final();
		System.out.println(tf.aa);
	}
}
