package com.orenda.service;


public interface IAdminService {


	
}
