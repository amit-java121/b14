package loops;

public class ForLoppExa {
	
	public static void main(String[] args) {
		
		
		int[] intArray = new int[5];
		intArray[0] = 10;
		intArray[1] = 20;
		intArray[2] = 30;
		intArray[3] = 40;
		intArray[4] = 50;
		
		
		
		for(int i=0;i<intArray.length;i++) {
			
			System.out.println(intArray[i]);
		}
		
		
		
		
//		for(int i=0;i<5;i++) {
//			aa:
//			for(int j=0;j<5;j++) {
//				 System.out.println("i= "+i);
//				if(i==2) {
//			       System.out.println(" if::");
//			       break aa;
//				}
//			}
//		}
		
	}

}
