package com;

public class DataTypes {
	
	boolean flag;
	String str ="this";
	char c ='a';
	float as = 2.34f;
	long ll = 121212111212121212l;
	double d = 112122222222222222222222222222.334444122222222222212221222222222222;
	Test test;
	
	
	
	public void m1() {
		
		int[] intArrauy = new int[5];
		intArrauy[0] =10;
		intArrauy[1] = 20;
		
		System.out.println(flag);
	}
	
	
	public static void main(String[] args) {
		
		DataTypes dt = new DataTypes();
		dt.m1();
		System.out.println(dt.flag);
		
		
	}

}
