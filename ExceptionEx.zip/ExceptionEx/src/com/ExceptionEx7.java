package com;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ExceptionEx7 {
	
	
	public void getUserDetails() throws IOException{
		
		File f = new File("");
		FileReader fr = new FileReader(f);
		
	}
	
	
	public void print() throws IOException {
		
		ExceptionEx7 ee = new ExceptionEx7();
		ee.getUserDetails();
	}

	
	
	public static void main(String[] args) {
		
		ExceptionEx7 ee = new ExceptionEx7();
		try {
			ee.print();
		} catch (IOException e) {
			System.out.println("custom message:::");
		}
		
	}

}
