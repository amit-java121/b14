package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.UserModel;
import com.it.service.IUserloginService;

@Controller
//@RequestMapping("/login")
public class LoginController {
	
	
	@Autowired
	IUserloginService loginService;
	
	@GetMapping("/")
	public String login() {
		
		System.out.println("login method called:::");
		return "login";
	}
	
	@GetMapping("/login")
	public String userLogin(@RequestParam("username") String username,@RequestParam("password") String password) {
		System.out.println("user login:::"+username+" "+password);
		boolean flag = loginService.checkUserDetails(username,password);
		if(flag) {
			return "userList";
		}
		
		return "login";
		
	}
	
	@GetMapping("/register")
	public ModelAndView registratrionPage() {
		
		ModelAndView modelAndView = new ModelAndView("userForm");
		modelAndView.addObject(new UserModel());
		
		System.out.println("registratrionPage:::");
		
		return modelAndView;
	}
	
	@PostMapping("/save")
	public void saveUserDetails(@ModelAttribute UserModel userModel) {
		
		System.out.println(userModel.toString());
	}
	

}
