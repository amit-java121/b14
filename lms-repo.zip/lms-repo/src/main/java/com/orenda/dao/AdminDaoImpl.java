package com.orenda.dao;

import org.springframework.stereotype.Repository;


@Repository
public class AdminDaoImpl implements IAdminDao {

		
}
