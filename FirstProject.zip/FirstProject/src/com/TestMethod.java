package com;

public class TestMethod {
	
	public int subtract(int c) {
		
		MethodsExa me = new MethodsExa();
		int sum = me.add(10, 10);
		
		int sub = sum-c;
		//System.out.println("sub :: "+sub);
		
		return sub;
	}
	
	public static void main(String[] args) {
//		MethodsExa me = new MethodsExa();
//		me.add(10, 20);
		
		TestMethod tm = new TestMethod();
		int afterSub= tm.subtract(5);
		
		System.out.println("afterSub"+afterSub);
	}

}
