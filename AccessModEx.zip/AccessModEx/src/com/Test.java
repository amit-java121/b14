package com;

public class Test {
	
	public Customer setData() {
		
		Customer customer = new Customer();
		customer.setCustomerName("amit");
		customer.setCustomerID(10100);
		customer.setCustomerAdress("pune");
		
		return customer;
	}
	
	
	public static void main(String[] args) {
		
		Test t = new Test();
		Customer cust = t.setData();
		System.out.println(cust.getCustomerID());
		System.out.println(cust.getCustomerName());
		System.out.println(cust.getCustomerAdress());
	}

}
