import java.util.ArrayList;
import java.util.List;

public class SaveUserData {
	
	public static void main(String[] args) {
		
		//data 
//		User user = new User();
//		user.setId(104);
//		user.setUserName("Saipan");
//		user.setAddress("mumbai");
//		user.setMobileNumber(1919199191);
//		
//		User user1 = new User();
//		user1.setId(105);
//		user1.setUserName("Snehal");
//		user1.setAddress("pune");
//		user1.setMobileNumber(1919199191);
//		
//		User user2 = new User();
//		user2.setId(103);
//		user2.setUserName("Sudan");
//		user2.setAddress("pune");
//		user2.setMobileNumber(1919199191);
//		
//		List<User> list = new ArrayList<>();
//		
//		list.add(user);
//		list.add(user1);
//		list.add(user2);
//		
//		
//		
//		JdbcConnectionTest jct = new JdbcConnectionTest();
//		jct.saveUserDetails(list);
		
		deleteUserRecord();
		
	}
	
	
	//delete
	public static void deleteUserRecord() {
		
		JdbcConnectionTest jct = new JdbcConnectionTest();
		jct.deleteUser(103);
		
	}

}
