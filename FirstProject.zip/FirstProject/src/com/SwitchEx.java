package com;

public class SwitchEx {
	
	public static void main(String[] args) {
		SwitchEx se = new SwitchEx();
		se.testSwitch();
	}
	
	public void testSwitch() {
		
		int age =50;
		
		switch (age) {
		case 10:
			System.out.println("we are in 10::");
			break;
		case 20:
			System.out.println("we are in 20::");
			break;
			
		case 0:
			System.out.println("we are in 30::");
			break;

		default:
			System.out.println("we are in default::::");
			break;
		}
		
	}

}
