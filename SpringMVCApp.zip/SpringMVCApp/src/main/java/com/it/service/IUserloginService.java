package com.it.service;

public interface IUserloginService {

	boolean checkUserDetails(String username, String password);

}
