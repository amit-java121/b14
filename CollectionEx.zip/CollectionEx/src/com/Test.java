package com;

import java.util.ArrayList;

public class Test {
	
	
	public static void main(String[] args) {
		
		TestEmployee te = new TestEmployee();
		
		ArrayList<Employee> list = te.addEmployeeData();
		
		
		System.out.println(list.get(0).getEmpId());
		
		ArrayList<Employee> newList = new ArrayList<>();
		for(Employee li:list) {
			
			if(li.getEmpAddress().equalsIgnoreCase("pune")) {
				newList.add(li);
//				System.out.println(li.getEmpId());
//				System.out.println(li.getEmpName());
//				System.out.println(li.getEmpAddress());
			}
		
		}
		System.out.println(newList);
		
	}

}
