package com;

public class A {
	
	protected  String str = "hello ";
	
	protected void m1() {
		System.out.println("m1 of class A");
	}

}
