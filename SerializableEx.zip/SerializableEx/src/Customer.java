
public class Customer extends Payment{

	private static final long serialVersionUID = 1L;
	private String customerName;
	private String customerAddress;
	
	
	public Customer(int userId, long cardNumber, int cvv, String userName, String customerName,
			String customerAddress) {
		super(userId, cardNumber, cvv, userName,null);
		this.customerName = customerName;
		this.customerAddress = customerAddress;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getCustomerAddress() {
		return customerAddress;
	}


	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	
	

}
