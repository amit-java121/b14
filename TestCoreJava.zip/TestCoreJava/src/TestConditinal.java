
public class TestConditinal {
	
	public static void main(String[] args) {
//		int age =20;
//		
//		if(age > 30) {
//			System.out.println("if executed");
//		}else {
//			System.out.println("else executed");
//		}
		
		
		int studentMarks =50;
		
		if(studentMarks == 30) {
			System.out.println("marks is "+studentMarks);
		}else if(studentMarks == 40) {
			System.out.println("marks is "+studentMarks);
		}else if(studentMarks == 50) {
			System.out.println("marks is "+studentMarks);
		}else {
			System.out.println("default no marks:::");
		}
		
	}

}
