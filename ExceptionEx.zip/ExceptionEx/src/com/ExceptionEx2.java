package com;

public class ExceptionEx2 {
	
	public int division(int a,int b,String str) {
		int c=0;
		
		System.out.println("before division::");
			try {
				
				c = a / b;
			}catch(ArithmeticException e) {
				System.out.println("arithmetic ex:::");
			}
			
			try {
				System.out.println("before if::::::::::");
				if(str.equals("abc")) {
					System.out.println("inside if");
				}
			
				} catch (NullPointerException ae) {
					System.out.println("nullpointer exception  defined message write here::");
				}
		
		System.out.println("after division::");
		return c;
		
	}
	
	public static void main(String[] args) {
		
		ExceptionEx2 ee = new ExceptionEx2();
		ee.division(10, 0, "abc");
	}

}
