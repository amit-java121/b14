import java.util.Scanner;

public class TestLoops {
	
	public static void main(String[] args) {
		
		int[] intarray = new int[10];
//		
		intarray[0]=10;
		intarray[1]=20;
		intarray[2]=30;
		intarray[3]=40;
		intarray[4]=50;
		intarray[5]=60;
//		
//		
//		for(int a=0;a<intarray.length;a++) {
//			System.out.println(intarray[a]);
//		}
//		
		
//		Scanner sc = new Scanner(System.in);
//		String str = sc.nextLine();
//		
//		while(str.equals("amit")) {
//			
//			System.out.println(str);
//			str= "amittt";
//		}
		
		//int i=5;
		do {
			
			System.out.println("do executed:::");
			//i++;
		}while(false);
		
	}

}
