package com;

public class StringBufferTest {
	
	public static void main(String[] args) {
		
		String str ="hello";
		str.concat("world");
		//System.out.println(str);
		
		StringBuffer sb = new StringBuffer("test");
		sb.append("string buffer");
		
		//System.out.println(sb);
		
		System.out.println(sb.capacity());
		System.out.println(sb.insert(5, "abcc"));
		System.out.println(sb.subSequence(5, 10));
		
		//reverse
		
		StringBuffer sb1 = new StringBuffer("hello");
		System.out.println(sb1.delete(1,3));
		
//		for(int i=sb1.length()-1;i>=0;i--) {
//			System.out.print(sb1.charAt(i));
//		}
		
	}

}
