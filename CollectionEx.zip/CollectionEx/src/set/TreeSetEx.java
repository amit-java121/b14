package set;

import java.util.TreeSet;

public class TreeSetEx {
	
	public static void main(String[] args) {
		TreeSet<String> treeSet = new TreeSet<>();
		treeSet.add("pqr");
		treeSet.add("abc");
		treeSet.add("abc");
		treeSet.add("abc1");
		treeSet.add("abc2");
		//treeSet.add(null);
		
		System.out.println(treeSet.descendingSet());
		
	}

}
