package com.orenda.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.orenda.model.UserDetails;



@Repository
public class ClientDaoImpl implements IClientDao{
    @Autowired 
    SessionFactory sessionFactory;
    
    
	public boolean saveUserData(UserDetails client) {
		boolean flag = false;
		try {
			System.out.println("inside the dao");
			Session session = sessionFactory.getCurrentSession();
			session.save(client);
			System.out.println("save data in dao");
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return flag;

	}

	

}
