package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestCustomer {
	
	public void setCustomerData() {
		
		Customer customer = new Customer(103, "Akshya", "pune");
		Customer customer1 = new Customer(101, "rohan", "pune");
		Customer customer2 = new Customer(102, "Snehal", "mumbai");
		Customer customer3 = new Customer(100, "Prashant", "nagpur");
		
		List<Customer> list = new ArrayList<>();
		
		list.add(customer);
		list.add(customer1);
		list.add(customer2);
		list.add(customer3);
		
		Collections.sort(list, new CustomerId());
		
		System.out.println(list);
		
		
		Collections.sort(list, new CustomerName());
		
		System.out.println(list);
		
//		List<String> strList = new ArrayList<>();
//		strList.add("abc");
//		strList.add("xyz");
//		strList.add("pqr");
//		
//		Collections.sort(strList);
//		System.out.println(strList);
		
		
	}
	
	
	public static void main(String[] args) {
		TestCustomer tc = new TestCustomer();
		tc.setCustomerData();
	}

}
