package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestReadEx {
	
	public static void main(String[] args) throws IOException {
		String str ="welcome to xpert it";
		File f = new File("C:\\Users\\Amit\\Desktop\\xpert.txt");
		FileOutputStream  fos = new FileOutputStream(f);
		fos.write(str.getBytes());
		fos.close();
		
		
		FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\xpert.txt");
		int i=0;
		while((i=fis.read())!=-1) {
			System.out.print((char)i);
		}
		
		fis.close();
		
	}

}
