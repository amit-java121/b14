package map;

import java.util.TreeMap;

public class TreeMapEx {
	
	public static void main(String[] args) {

		TreeMap<Integer, String> treemap = new TreeMap<Integer, String>();
		
		treemap.put(101, "rohan");
		treemap.put(104, "prashant");
		treemap.put(103, "Akshya");
		treemap.put(100, "rohan");
		//treemap.put(null, null);
		treemap.put(105, null);
		
		System.out.println(treemap.descendingMap());
	}

}
