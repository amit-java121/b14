package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.ILoginUserDao;
import com.it.model.UserModel;

@Service
@Transactional
public class UserServiceImpl implements IUserloginService{
	
	@Autowired
	ILoginUserDao loginDao;

	@Override
	public void checkUserDetails(String username, String password) {

		UserModel user = loginDao.getUserDetails(username);
		//validate
	}

}
