package com;


public class ExceptionEx3 {
	
	public void test(int a,int b,String str) {
		
		try {
			
			if(str.equals("abc")) {
				System.out.println("if condtion executed::");
			}
			
			try{
				
				int c =a/b;
				
			}catch(ArithmeticException ae) {
				System.out.println("arithematic exception catch block::");
				ae.printStackTrace();
			}
			
			
		}catch(Exception e) {
			System.out.println("exception catch block::");
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		ExceptionEx3 ee = new ExceptionEx3();
		ee.test(10, 0, "abc");
	}

}
