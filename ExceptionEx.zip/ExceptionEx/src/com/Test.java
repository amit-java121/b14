package com;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Test {
	
	public void m1(int b,int c) throws Exception{
		System.out.println("m1 called::");
		int a=0;
		try {
		   
			 a = b/c;
		   
		}catch(Exception e) {
			
			//System.out.println("inside catch block");
		}
		System.out.println(a);
		System.out.println("logic after division");
		System.out.println("logic after division");
		System.out.println("logic after division");
	}
	
	public void add() {
		System.out.println("add called");
	}
	
	public static void main(String[] args) {
		
		//BufferedReader bf = new BufferedReader(new FileReader("asasas"));
		
		Test t = new Test();
		try {
			t.m1(10,2);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		t.add();
		
	}

}
