package springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springboot.dao.CustomerRepository;
import springboot.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerRepository repository;

	@Override
	public Customer verifyCustomerCredentials(String username, String passowrd) {
		
		Customer customer = repository.findUserByEmail(username);
		return customer;
	}

}
