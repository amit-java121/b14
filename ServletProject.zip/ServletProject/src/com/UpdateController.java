package com;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.UserModel;
import com.service.UserService;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		if(request.getParameter("userEmail") == null) {
			String id = request.getParameter("id");
			
			UserService service = new UserService();
			UserModel userModel = service.getUser(Integer.valueOf(id));
			
			request.setAttribute("user", userModel);
			RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
			rd.forward(request, response);
		}else {
			UserModel userModel = new UserModel();
			
			userModel.setId(Integer.valueOf(request.getParameter("id")));
			userModel.setUserName(request.getParameter("userName"));
			//userModel.setUserPass(request.getParameter("password"));
			userModel.setUserEmail(request.getParameter("userEmail"));
			userModel.setMobileNo(Long.valueOf(request.getParameter("userMBNumber")));
			userModel.setGender(request.getParameter("gender"));
			userModel.setCountry(request.getParameter("country"));
			
			UserService service = new UserService();
			boolean flag = service.updateUserDetails(userModel);
			
			if(flag) {
				List<UserModel> listOfUsers = service.getUserDetails();
				
				request.setAttribute("list", listOfUsers);
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}else {
				List<UserModel> listOfUsers = service.getUserDetails();
				request.setAttribute("list", listOfUsers);
				request.setAttribute("message", "User record is not updated!!!. please try again::");
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}
			
		}
		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
