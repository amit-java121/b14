package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.UserModel;
import com.mysql.cj.protocol.Resultset;

public class UserDBConnection {
	
	public UserModel fetchUserDetails(String userName) {
		UserModel userModel = new UserModel();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select  user_name,user_pass from login_tbl where user_name='"+userName+"'");
			
			
			while(rs.next()) {
				userModel.setUserName(rs.getString(1));
				userModel.setUserPass(rs.getString(2));
				
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userModel;
	}

	public boolean saveUserDeayisl(UserModel userModel) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			
				PreparedStatement pstmt = con.prepareStatement("insert into login_tbl values(?,?,?,?,?,?,?)");
				pstmt.setInt(1, userModel.getId());
				pstmt.setString(2, userModel.getUserName());
				pstmt.setString(3, userModel.getUserPass());
				pstmt.setString(4, userModel.getCountry());
				pstmt.setString(5, userModel.getUserEmail());
				pstmt.setLong(6, userModel.getMobileNo());
				pstmt.setString(7, userModel.getGender());
				
				int i = pstmt.executeUpdate();
			 if(i > 0) {
				 return true;
			 }
				
				
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public List<UserModel> fetchAllUserDetails() {
		List<UserModel> userList = new ArrayList<>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			
			Statement stmt = con.createStatement();
			
			 ResultSet rs = stmt.executeQuery("select * from login_tbl");
		
			 while(rs.next()) {
				 UserModel userModel = new UserModel();
				 
				 userModel.setId(rs.getInt(1));
				 userModel.setUserName(rs.getString(2));
				 userModel.setUserPass(rs.getString(3));
				 userModel.setCountry(rs.getString(4));
				 userModel.setUserEmail(rs.getString(5));
				 userModel.setMobileNo(rs.getInt(6));
				 userModel.setGender(rs.getString(7));
				 
				 userList.add(userModel);
			 }
			 
			 
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userList;
	}

	public boolean deleteUser(int id) {
		
		boolean flag=false;
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
		Statement stmt = con.createStatement();
		
		int i= stmt.executeUpdate("delete from login_tbl where id='"+id+"'");
		
		if(i>0) {
			flag = true;
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}

	public UserModel getUser(Integer id) {
		UserModel userModel = new UserModel();
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
		Statement stmt = con.createStatement();
		
		ResultSet rs= stmt.executeQuery("select * from login_tbl where id='"+id+"'");
		
		while(rs.next()) {
			 userModel.setId(rs.getInt(1));
			 userModel.setUserName(rs.getString(2));
			 userModel.setUserPass(rs.getString(3));
			 userModel.setCountry(rs.getString(4));
			 userModel.setUserEmail(rs.getString(5));
			 userModel.setMobileNo(rs.getInt(6));
			 userModel.setGender(rs.getString(7));
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userModel;
		
	}

	public boolean updateUserDetails(UserModel userModel) {
		boolean flag =false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			
			PreparedStatement pstmt = con.prepareStatement("update login_tbl set user_name=?,country=?,user_email=?,mobile_no=?,gender=? where id=?");
			
			pstmt.setString(1, userModel.getUserName());
			pstmt.setString(2, userModel.getCountry());
			pstmt.setString(3, userModel.getUserEmail());
			pstmt.setLong(4, userModel.getMobileNo());
			pstmt.setString(5, userModel.getGender());
			pstmt.setInt(6, userModel.getId());
			
			int i = pstmt.executeUpdate();
			
			if(i>0) {
				flag =true;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}

}
