
public class TestSwitchEx {
	
	private static TestSwitchEx ts;
	
	public static void main(String[] args) {
		   ts = new TestSwitchEx();
		ts.testSwitch("FEB");
		
	}
	
	
	public void testSwitch(String monthName) {
	
		switch (monthName) {
		case "JAN":
			System.out.println("01");
			break;

		case "FEB":
			System.out.println("02");
			break;
			
		case "MAR":
			System.out.println("03");
			
			
			break;
			
		default:
			break;
		}
		
	}
	

}
