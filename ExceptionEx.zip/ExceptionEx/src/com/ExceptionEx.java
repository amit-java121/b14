package com;

public class ExceptionEx {
	
	public int division(int a,int b,String str) {
		int c=0;
		
		System.out.println("before division::");
		try {
			
			if(str.equals("abc")) {
				System.out.println("inside if");
			}
			
			//c = a / b;
		} catch (NullPointerException ae) {
			System.out.println("user defined message write here::");
		}
		System.out.println("after division::");
		return c;
		
	}
	
	public void test() {
		System.out.println("test called:::");
	}
	
	public static void main(String[] args) {
		ExceptionEx ee = new ExceptionEx();
		int division = ee.division(10, 0,null);
		System.out.println(division);
		
		ee.test();
	}

}
