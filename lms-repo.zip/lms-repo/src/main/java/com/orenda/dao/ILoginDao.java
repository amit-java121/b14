package com.orenda.dao;



import com.orenda.model.UserDetails;
import com.orenda.model.UserLogin;

public interface ILoginDao {

	UserLogin verifyUser(String userEmail);

	UserLogin savePassword(String userPass, String email);
	
	public UserDetails getUserDetails(String email);

	
	


}
