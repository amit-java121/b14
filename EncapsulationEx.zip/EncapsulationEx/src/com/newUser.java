package com;

public class newUser {

	private int userid;
	private String userName;
	private String address;
	
	
	
	public newUser(int userid, String userName, String address) {
		super();
		this.userid = userid;
		this.userName = userName;
		this.address = address;
	}
	
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "newUser [userid=" + userid + ", userName=" + userName + ", address=" + address + "]";
	}	
	
	
	
}
