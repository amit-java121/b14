import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class TestPSmt {
	
	public static void main(String[] args) {
		
		
//		User user = new User();
//		user.setId(111);
//		user.setUserName("Akshya");
//		user.setAddress("pune");
//		user.setMobileNumber(98181819);
//		
//		User user1 = new User();
//		user1.setId(106);
//		user1.setUserName("Snehal");
//		user1.setAddress("pune");
//		user1.setMobileNumber(1919199191);
//		
//		User user2 = new User();
//		user2.setId(107);
//		user2.setUserName("Sudan");
//		user2.setAddress("pune");
//		user2.setMobileNumber(1919199191);
//		
//		List<User> list = new ArrayList<>();
//		
//		list.add(user);
//		list.add(user1);
//		list.add(user2);
//		
//		
		JdbcConnectionTest jct = new JdbcConnectionTest();
//		jct.saveUserDetailsUsingPsmt(list);
		
		//fetchUserDataById();
		
		Map<Integer, User> map = jct.getUserAllDetails();
		
		  Collection<User> user = map.values();
		System.out.println(user.toString());
		
//		for( Entry<Integer, User> m:map.entrySet()) {
//			System.out.println("key: "+m.getKey()+" value: "+m.getValue());
//		}
		
	}
	
	public static void fetchUserDataById() {
		JdbcConnectionTest jct = new JdbcConnectionTest();
		User user = jct.fetchUserById(110);
		System.out.println(user.toString());
	}

}
