package transaction;

public class Transaction extends Thread{
	
	static int balance = 2000;

	@Override
	public void run() {
		for(int i=0;i<3;i++) {
		withdrawn(400);
		}
	}

	private static synchronized void withdrawn(int amt) {
		System.out.println("trying to withdrawn:"+Thread.currentThread().getName());
		if(balance > amt) {
			balance = balance-amt;
			System.out.println("withdrawn amount : "+balance+ " "+Thread.currentThread().getName());
		}else {
			System.out.println("insufficient fund:::");
		}
		
	}
	

}
