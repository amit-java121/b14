package com;

public class Car implements Vehicle{

	@Override
	public int wheels() {
		
		return 4;
	}

	@Override
	public String engine() {
		// TODO Auto-generated method stub
		return "two strokes";
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "Green";
	}

	@Override
	public int seats() {
		// TODO Auto-generated method stub
		return 5;
	}

}
