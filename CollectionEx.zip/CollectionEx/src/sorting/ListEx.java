package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListEx {
	
	public static void main(String[] args) {
//		List<String> list = new ArrayList<>();
//		list.add("abc1");
//		list.add("xyz");
//		list.add("abc2");
//		list.add("pqr");
		
		List<Employee> list = new ArrayList<>();
		Employee emp = new Employee(100, "rohan", "pune");
		Employee emp1 = new Employee(101, "rohan1", "mumbai");
		Employee emp2 = new Employee(103, "rohan2", "pune");
		Employee emp3 = new Employee(102, "rohan3", "nagpur");
		
		list.add(emp);
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		
		Collections.sort(list);
		
		List<Employee> unmodifiable = Collections.unmodifiableList(list);
		
		//unmodifiable.add(emp1);
		
		for(Employee l:unmodifiable) {
			System.out.println(l);
		}
	
	}

}
