package com;

import java.util.LinkedList;

public class LinkedListTest {
	
	public static void main(String[] args) {
		LinkedList<String> linkedList = new LinkedList<>();
		linkedList.add("abc");
		linkedList.add("abc1");
		linkedList.add("abc2");
		
		System.out.println(linkedList);
	}

}
