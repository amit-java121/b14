package com.it.service;

import java.util.List;

import com.it.model.UserModel;

public interface IUserloginService {

	boolean checkUserDetails(String username, String password);

	boolean saveUserDetails(UserModel userModel);
	
	public List<UserModel> getAllUserData();

	String deleteUserRecord(int id);

}
