package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.UserModel;
import com.it.service.IUserloginService;

@Controller
//@RequestMapping("/first")
public class LoginController {
	
	
	@Autowired
	IUserloginService loginService;
	
	@GetMapping("/")
	public String login() {
		
		System.out.println("login method called:::");
		return "login";
	}
	
	@GetMapping("/login")
	public String userLogin(@RequestParam("username") String username,@RequestParam("password") String password) {
		System.out.println("user login:::"+username+" "+password);
		boolean flag = loginService.checkUserDetails(username,password);
		if(flag) {
			return "redirect:/getUserData";
		}
		
		return "login";
		
	}
	
	@GetMapping("/register")
	public ModelAndView registratrionPage() {
		
		ModelAndView modelAndView = new ModelAndView("userForm");
		modelAndView.addObject(new UserModel());
		
		System.out.println("registratrionPage:::");
		
		return modelAndView;
	}
	
	@PostMapping("/save")
	public String saveUserDetails(@ModelAttribute UserModel userModel) {
		
		System.out.println(userModel.toString());
		
		boolean flag = loginService.saveUserDetails(userModel);
		
		if(flag) {
			return "redirect:/getUserData";
		}
		
		return "userForm";
	}
	
	@GetMapping("/getUserData")
	public String getAllUserData(Model model , @RequestParam(required = false) String message ) {
		//ModelAndView modelAndView = new ModelAndView("userList");
		List<UserModel> userData = loginService.getAllUserData();
		//modelAndView.addObject("listOfUser", userData);
		model.addAttribute("listOfUser", userData);
		model.addAttribute("message", message);
		System.out.println(userData.toString());
		
		return "userList";
	}
	
	@GetMapping("/delete")
	public String deleteUserRecord(@RequestParam("id") int id,Model model) {
		System.out.println("user id "+id);
		
		String msg = loginService.deleteUserRecord(id);
		
		
		if(msg.equalsIgnoreCase("success")) {
			model.addAttribute("message", "User recored is deleted successfully!!!");
			return "redirect:/getUserData";		
		}else if(msg.equals("absent")) {
			model.addAttribute("message", "User recored is not present");
			return "userList";
		}else {
			model.addAttribute("message", "Record is not deleted due to connection issue please try again!!");
		}
		
		return "userList";
	}
	
	@GetMapping("/update")
	public ModelAndView edit(@RequestParam("id") int id,Model model) {
		System.out.println("id "+id);
		UserModel user = loginService.editUser(id);
		ModelAndView modelAndView = new ModelAndView("userForm");
		modelAndView.addObject("userModel", user);
		
		return modelAndView;
	}

	@GetMapping("/home")
	public String goToHome() {
		
		return "login";
	}
}
