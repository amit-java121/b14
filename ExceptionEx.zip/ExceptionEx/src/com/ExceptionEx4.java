package com;

public class ExceptionEx4 {
	
	public int division(int a,int b) {
		int c=0;
		
		System.out.println("before division::");
			try {
				
				
				c = a / b;
			}catch(ArithmeticException e) {
				System.out.println("arithmetic ex:::");
			}finally {
			//db connection close
			// file connection close
				System.out.println("finally block executed::");
			}
			
		return c;
		
	}
	
	
 public int division1(int a,int b) {
		int c=0;
		
		System.out.println("before division::");
			try {
				
				
				c = a / b;
			}finally {
			//db connection close
			// file connection close
				System.out.println("finally block executed::");
			}
			
		return c;
		
	}
	
	
	public static void main(String[] args) {
		ExceptionEx4 ee = new ExceptionEx4();
		ee.division(10, 0);
	}

}
