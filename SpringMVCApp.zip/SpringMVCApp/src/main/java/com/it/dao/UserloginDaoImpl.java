package com.it.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.UserModel;

@Repository
public class UserloginDaoImpl implements ILoginUserDao{
	
	@Autowired
	SessionFactory sessionFactory;
	

	@Override
	public UserModel getUserDetails(String username) {

		System.out.println("user name "+username);
		UserModel user = null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from UserModel where userEmail=:email");
		List userModel = query.setParameter("email", username).getResultList();
		
		//System.out.println(userModel.toString());
		if(userModel.size() > 0) {
			 user = (UserModel)userModel.get(0);
		}
		
		return user;
		
	}

}
