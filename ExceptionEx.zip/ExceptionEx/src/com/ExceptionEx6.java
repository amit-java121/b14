package com;

public class ExceptionEx6 {
	
	public void readDataFromExcel() {
	
		
		//Class.forName("");
		
//		File f = new File("");
//		FileReader fr = new FileReader(f);
		
		
		//BufferedReader br = new BufferedReader(fr);
		
	}
	
	public static void main(String[] args) {
		
	}

}
