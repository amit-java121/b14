import java.util.List;

public class TestUserData {
	
	public static void main(String[] args) {
		
		JdbcConnectionTest jct = new JdbcConnectionTest();
		List<User> userList = jct.getUserDetails();
		System.out.println(userList.toString());
		
	}

}
