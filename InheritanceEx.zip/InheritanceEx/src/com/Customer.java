package com;

public class Customer {
	int cutomerID;
	String customerName;
	String customerAddress;
	
	
	public int getCutomerID() {
		return cutomerID;
	}
	public void setCutomerID(int cutomerID) {
		this.cutomerID = cutomerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	
	
//	public Customer(int cutomerID, String customerName, String customerAddress) {
//		super();
//		this.cutomerID = cutomerID;
//		this.customerName = customerName;
//		this.customerAddress = customerAddress;
//	}
	
	
	

}
