package com.it.service;

public interface IUserloginService {

	void checkUserDetails(String username, String password);

}
