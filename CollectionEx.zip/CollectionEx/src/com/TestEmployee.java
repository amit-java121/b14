package com;

import java.util.ArrayList;

public class TestEmployee {
	
	
	public ArrayList<Employee> addEmployeeData() {
		
		ArrayList<Employee> list = new ArrayList<Employee>();
		Employee emp = new Employee();
		emp.setEmpId(101);
		emp.setEmpName("Akshya");
		emp.setEmpAddress("pune");
		
		Employee emp1 = new Employee();
		emp1.setEmpId(102);
		emp1.setEmpName("Rohan");
		emp1.setEmpAddress("mumbai");
		
		Employee emp2 = new Employee();
		emp2.setEmpId(103);
		emp2.setEmpName("Prashant");
		emp2.setEmpAddress("Nagpur");
		
		
		list.add(emp);
		list.add(emp1);
		list.add(emp2);
		
		
		
		
		return list;
	}

}
