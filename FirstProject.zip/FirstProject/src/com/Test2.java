package com;

public class Test2 {
	
	public static int add(int a,int b) {
		//int c =a+b;
		return a+b;
	}
	
	
	public static void main(String[] args) {
		
		//Test2 t2 = new Test2();
		System.out.println(Test2.add(10,20));
	}

}
