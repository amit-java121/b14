import java.io.Serializable;

public class Payment implements Serializable{

	private static final long serialVersionUID = -8628696343552641436L;
	
	private transient int userId;
	private long cardNumber;
	private int cvv;
	private static String userName;
	
	private Address address;
	
	public Payment(int userId, long cardNumber, int cvv, String userName,Address address) {
		super();
		this.userId = userId;
		this.cardNumber = cardNumber;
		this.cvv = cvv;
		this.userName = userName;
		this.address = address;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public long getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Payment [userId=" + userId + ", cardNumber=" + cardNumber + ", cvv=" + cvv + ", userName=" + userName
				+ "]";
	}
	
	
}
