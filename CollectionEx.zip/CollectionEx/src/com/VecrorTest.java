package com;

import java.util.Vector;

public class VecrorTest {
	
	
	public static void main(String[] args) {
		
		Vector<String> vector = new Vector<>();
		vector.addElement("abc1");
		vector.addElement("abc2");
		vector.add("pqr");
		
		System.out.println(vector.removeElement("pqr"));
		System.out.println(vector);
		
	}

}
