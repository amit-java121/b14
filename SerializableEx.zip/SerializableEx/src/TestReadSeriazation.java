import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TestReadSeriazation {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\payment.txt");
		
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Payment payment = (Payment)ois.readObject();
		ois.close();
		System.out.println(payment.toString());
		
	}

}
