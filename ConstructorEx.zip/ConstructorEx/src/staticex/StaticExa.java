package staticex;

public class StaticExa {
	
	static String name ;
	int age=25;
	
	public static void print() {
		System.out.println("KKKKKKK");
		StaticExa see = new StaticExa();
		see.age=30;
	}
	
	public void test() {
		System.out.println(name);
	}
	
	
	public StaticExa() {
		System.out.println("const:::");
	}
	
	static {
		name = "prashant";
		System.out.println("we are inside static block::");
	}
	
	
	public static void main(String[] args) {
		StaticExa se = new StaticExa();
		System.out.println(name);
		print();
	}

}
