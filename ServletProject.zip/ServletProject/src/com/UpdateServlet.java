package com;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.UserService;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		if(request.getParameter("userEmail") == null) {
			
			
			System.out.println("idd:  "+request.getParameter("idd"));
			
			String userID = request.getParameter("idd");
			Integer id= Integer.valueOf(userID);
			
			UserService userService = new UserService();
			User user = userService.fetchSingleUserRecord(id);
			
			if(user != null) {
				request.setAttribute("user", user);
				RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
				rd.forward(request, response);
			}
		}else {
			
			User user = new User();
			String userID = request.getParameter("id");
			Integer id= Integer.valueOf(userID);
			user.setId(id);
			user.setUserName(request.getParameter("userName"));
			//user.setUserPass(request.getParameter("password"));
			user.setUserEmail(request.getParameter("userEmail"));
			user.setGender(request.getParameter("gender"));
			user.setMobNumber(Long.valueOf(request.getParameter("userMBNumber")));
			user.setCountry(request.getParameter("country"));
			
			//Call service
			UserService userService = new UserService();
			boolean flag= userService.updateUserDetails(user);
			
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
