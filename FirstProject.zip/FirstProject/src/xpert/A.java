package xpert;

public class A {
	
	
	public int add() {
		int a=10;
		int b=20;
		int c=a+b;
		
		return c;
	}

}
