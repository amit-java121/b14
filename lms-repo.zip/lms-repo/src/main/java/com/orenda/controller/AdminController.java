package com.orenda.controller;

import org.springframework.stereotype.Controller;

@Controller
public class AdminController {
	
		
}
