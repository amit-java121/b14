package com;

public class Bus implements Vehicle{

	@Override
	public int wheels() {
		// TODO Auto-generated method stub
		return 6;
	}

	@Override
	public String engine() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public int seats() {
		// TODO Auto-generated method stub
		return 45;
	}
	
	

}
