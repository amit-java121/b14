package com.orenda.controller;

import java.util.Random;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.orenda.model.UserDetails;
import com.orenda.service.ILoginService;

@Controller
public class LoginController {

	@Autowired
	ILoginService service;

	@GetMapping("/")
	public String loginUser() {
		return "loginPage";

	}

	@GetMapping("/forgot")
	public String forgotPassword() {
		return "Forget-Page";

	}

	@GetMapping("/cl")
	public String client() {
		return "client";

	}

	@GetMapping("/validateUser")
	public String checkUser(@RequestParam("email") String email, Model model) {

		boolean flag = service.checkUser(email);
		if (flag) {
			System.out.println("Link send Successfully");
			model.addAttribute("msg", "Link sent successfully on your mail");
			// return "redirect:/Forget-page";
			// return "Forget-Page";

		} else {
			model.addAttribute("msg", "user is invalid");
		}

		return "Forget-Page";

	}

	@GetMapping("/updatePass")
	public String updatePassword(Model model, @RequestParam("email") String email) {

		System.out.println("inside of page");
		System.out.println(email);
		model.addAttribute("email", email);
		return "ForgetPasswordLink-page";

	}

	@GetMapping("/savePassword")
	public String savePassword(@RequestParam("up") String userPass, @RequestParam("email") String email) {
		System.out.println("password save" + " " + userPass);
		System.out.println("useremail" + " " + email);
		service.savePassword(userPass, email);
		return "ForgetPasswordLink-page";

	}

	@GetMapping("/login")
	public String checkLogin(@RequestParam("userEmail") String email, @RequestParam("password") String UIpassword,
			Model model, HttpServletRequest request, HttpServletResponse response) {

		boolean cookieVerify = false;

		String checkBox = request.getParameter("cookie");
		Cookie cookies[] = request.getCookies();
		String cookie = null;

		for (int i = 0; i < cookies.length; i++) {

			if (cookies[i].getValue().equals(email)) {
				cookieVerify = true;
				System.out.println(cookies[i].getValue() + "   valuee of cookies  " + cookieVerify);
				System.out.println(cookies[i].getName() + " hhhhhhhhhhhhhhhhhhhhhhhh");

			}

		}

		// for remember me
		if (email != "" && UIpassword != "" && checkBox != null) {

			System.out.println("  first.......");
			boolean check = service.checklogin(email, UIpassword);
			System.out.println(email + "   " + check);
			System.out.println(UIpassword + "   " + check);

			if (check) {
				String type = service.userType(email);
				System.out.println(" first111............");

				if (checkBox != null) {

					String str = email;
					Random randomNumber = new Random();
					int Rnumber = randomNumber.nextInt();
					System.out.println(Rnumber + "   randomnumer");
					Cookie emailCookie = new Cookie("u" + Rnumber, email);

					Cookie passwordCookie = new Cookie("p" + Rnumber, UIpassword);

					emailCookie.setMaxAge(86400);
					passwordCookie.setMaxAge(86400);

					response.addCookie(emailCookie);
					System.out.println();

					response.addCookie(passwordCookie);

					if (type.equals("admin")) {
						return "admin";
					} else if (type.equals("employee")) {
						return "employee";
					} else if (type.equals("user")) {
						return "user";
					}

				}

			} else {
				model.addAttribute("msg", "username or password are incorrect");
				return "loginPage";
			}

		}

		// for not remember me
		else if (email != "" && UIpassword != "") {
			boolean check = service.checklogin(email, UIpassword);
			
			System.out.println(" ...k.k.kk.k.k."+"   "+check);
			if (check) {
				String type = service.userType(email);

				
				if (type.equals("admin")) {
					return "admin";
				} else if (type.equals("employee")) {
					return "employee";
				} else if (type.equals("user")) {
					return "user";
				}

			} else {
				model.addAttribute("msg", "username or password are incorrct");
				return "loginPage";

			}

		}

		// for verify cookie
		else if (email != "" && cookieVerify) {
			System.out.println("  email only.........");
			// boolean check = service.checklogin(email, UIpassword);

			String type = service.userType(email);

			System.out.println(" veriiiii...");

			if (type.equals("admin")) {
				return "admin";
			} else if (type.equals("employee")) {
				return "employee";
			} else if (type.equals("user")) {
				return "user";
			}

		} else {
			model.addAttribute("expireCookie", "cookies are not found");
			return "loginPage";

		}
		return "unsucces";

	}

	
}