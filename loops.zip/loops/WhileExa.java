package loops;

public class WhileExa {
	
	public static void main(String[] args) {
		
		 int a=15;
		//boolean flag = true;
		
		while (a >10) {
			System.out.println("inside while loop");
			//flag=false;
			a--;
		}
		
	}

}
