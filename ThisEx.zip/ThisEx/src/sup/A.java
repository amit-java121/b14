package sup;

public class A {
	
	int age =50;
	int id =10101;
	
	public A() {
		System.out.println("const ::A ");
	}
	
	public void m1() {
		System.out.println("m1 of class A");
	}

}
