package com;

public class IfElseIfEx {
	public static void main(String[] args) {
		IfElseIfEx ie = new IfElseIfEx();
		ie.testElseIf(15);
		
	}
	
	
	public void testElseIf(int age) {
		if(age > 20) {
			
			System.out.println("if 20");
			
		}else if(age > 10){
			System.out.println("if 30 ");
		
		
		}else if(age > 15){
			System.out.println("if 40");
		
		}
		
		else {
			System.out.println("else");
		}
		
	}

}
