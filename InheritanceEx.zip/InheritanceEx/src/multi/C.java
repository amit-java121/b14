package multi;

public class C extends B{
	
	public void m3() {
		System.out.println("class C method m3() ");
	}
	
	
	public static void main(String[] args) {
		C c = new C();
		c.m1();
		c.m2();
		c.m3();
		
	}

}
