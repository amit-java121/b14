package com;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class BufferReaderTest {
	
	public static void main(String[] args) throws Exception {
		
		String str ="Hello world!!!";
		FileWriter fw = new FileWriter("C:\\Users\\Amit\\Desktop\\xpert.txt",true);
		
		   BufferedWriter bw = new BufferedWriter(fw);
				
				bw.write(str+"\n");
				bw.close();
				
		
		FileReader fr = new FileReader("C:\\Users\\Amit\\Desktop\\xpert.txt");
		BufferedReader bf = new BufferedReader(fr);
		int i=0;
		while((i=bf.read())!=-1) {
			System.out.print((char)i);
		}
		
		bf.close();
		
		
		
	}

}
