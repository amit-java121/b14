package sup;

public class InitBlockEx {
	
	int age;
	
	public InitBlockEx(){
		System.out.println("InitBlockEx const:::");
	}
	
	static {
		System.out.println("static block::");
	}
	
	{
		age =25;
		System.out.println("init block");
	}
	
	public void testAge() {
		System.out.println("age::: "+age);
	}
	
	public static void main(String[] args) {
		InitBlockEx ib = new InitBlockEx();
		ib.testAge();
		
	}

}
