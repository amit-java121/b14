package transaction;

public class TriggerTransaction {
	
	
	public static void main(String[] args) {
		
		Transaction transaction = new Transaction();
		transaction.setName("BANK");
	     transaction.start();	
	     
	     Transaction transaction1 = new Transaction();
			transaction1.setName("ATM");
		     transaction1.start();
		
	}

}
