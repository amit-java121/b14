package com;

public class User {

	int userID;
	String userName;
	String userAddress;
	long userMob;
	String userGender;
	
	public User() {
		
	}
	public User(int userID, String userName, String userAddress, long userMob, String userGender) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userAddress = userAddress;
		this.userMob = userMob;
		this.userGender = userGender;
	}
	
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public long getUserMob() {
		return userMob;
	}
	public void setUserMob(long userMob) {
		this.userMob = userMob;
	}
	public String getUserGender() {
		return userGender;
	}
	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}
	
	
	
}
