package com.orenda.service;

import com.orenda.model.UserDetails;

public interface ILoginService {

	public boolean checkUser(String userEmail);
	

	public boolean sendEmail(String subject, String message, String to);


	public void savePassword(String userPass, String email);

	public boolean checklogin(String email, String UIpassword);
	
	public String userType(String email);


}