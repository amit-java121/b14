package com;

public class Test {

	
	public void m1() {
		System.out.println("m1 called:: ");
	}
	
	public static void main(String[] args) {
		
		Test t = new Test();
		t.m1();
		
		t = null;
		
		System.gc();
		
		Test t1 = new Test();
		
		Test t2 = new Test();
		
	}

}
