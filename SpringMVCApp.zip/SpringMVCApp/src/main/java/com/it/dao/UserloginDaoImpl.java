package com.it.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.UserModel;

@Repository
public class UserloginDaoImpl implements ILoginUserDao{
	
	@Autowired
	SessionFactory sessionFactory;
	

	@Override
	public UserModel getUserDetails(String username) {

		System.out.println("user name "+username);
		UserModel user = null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from UserModel where userEmail=:email");
		List userModel = query.setParameter("email", username).getResultList();
		
		//System.out.println(userModel.toString());
		if(userModel.size() > 0) {
			 user = (UserModel)userModel.get(0);
		}
		
		return user;
		
	}


	@Override
	public boolean saveUserDetail(UserModel userModel) {
		
		Session session = sessionFactory.getCurrentSession();
		//Transaction tr = session.beginTransaction();
		  session.saveOrUpdate(userModel);
		 
		 //tr.commit();
		return true;
	}
	
	public List<UserModel> getAllUserData(){
		
		Session session = sessionFactory.getCurrentSession();
		List<UserModel> listOfUserModel = session.createCriteria(UserModel.class).list();
	
		
		return listOfUserModel;
	}


	@Override
	public String deleteUser(int id) {
		//boolean flag =false;
		String msg = "";
		try {
		Session session = sessionFactory.getCurrentSession();
		UserModel user = session.get(UserModel.class, id);
		
		if(user == null) {
			msg = "absent";
		}else {
			try {
			session.delete(user);
			msg = "success";
			}catch(Exception e) {
				msg = "failure";
				e.printStackTrace();
			}
		}
		
		//flag =true;
		}catch(Exception e) {

			e.printStackTrace();
		}
		return msg;
	}


	@Override
	public UserModel editUser(int id) {

		Session session = sessionFactory.getCurrentSession();
		UserModel user = session.get(UserModel.class, id);
		
		return user;
	}

}
