package method;

public class TriggerJoinTest {
	
	public static void main(String[] args) throws InterruptedException {
		
		TestJoin tj = new TestJoin();
		tj.start();
		tj.join();
		
		for(int i=10;i<20;i++) {
			System.out.println(i);
		}
		
	}

}
