package method;

public class ThreadA extends Thread{
	
	int sum =0;
	
	@Override
	public void run() {
		
		synchronized (this) {
			for(int i=0;i<10;i++) {
				sum +=i;
			}
			
			notify();
		}
		
		
		//System.out.println("threadA: "+sum);
	}

}
