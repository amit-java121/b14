import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestCustomer {
	
	public static void main(String[] args) throws Exception {
		

//		Customer customer = new Customer(1000, 15151551, 818, "test", "customer", "pune");
//		//Payment payment = new Payment(1000, 1515151515, 1511, "test");
//		
//		FileOutputStream fos = new FileOutputStream("C:\\Users\\Amit\\Desktop\\payment.txt");
//		
//		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		
//		oos.writeObject(customer);
//		
//		oos.flush();
//		oos.close();
		
		//read operation
		
		FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\payment.txt");
		
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Customer customer = (Customer)ois.readObject();
		ois.close();
		System.out.println(customer.getCustomerName());
		System.out.println(customer.getCvv());
		System.out.println(customer.getCardNumber());
		
		
	}

}
