package com;

import it.TestDefault;

public class TestD {
	
	public static void main(String[] args) {
		//TestDefault td = new TestDefault();
		//System.out.println(td.);
		
		//protected
		A a = new A();
		System.out.println(a.str);
		a.m1();
	}

}
