package com;

public class B extends A{

	String address = "Pune";
	
	
	public static void main(String[] args) {
//		A a = new A();
//		System.out.println(a.name);
		
		B b= new B();
		System.out.println(b.address);
		System.out.println(b.name);
		System.out.println(b.userName());
	}
	

}
