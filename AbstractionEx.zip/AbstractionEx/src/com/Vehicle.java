package com;

public interface Vehicle {
	
	int wheels();
	String engine();
	String color();
	int seats();
	

}
