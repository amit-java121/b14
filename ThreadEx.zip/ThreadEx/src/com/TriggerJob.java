package com;

public class TriggerJob {
	
	public static void main(String[] args) {
		
		System.out.println("thread name: "+Thread.currentThread().getName());
		
		for(int i=0;i<10;i++) {
			System.out.println("i="+i);
		}
		//System.out.println("thread name: "+Thread.currentThread().getName());
		Job job = new Job();
		job.setName("hdfcbank");
		job.start();
		
		Job newJob = new Job();
		newJob.setName("hdfcbank newJob");
		newJob.start();
		
		
		Job1 job1 = new Job1();
		job1.setName("icicibank");
		job1.start();
		
		System.out.println("exit thread : "+Thread.currentThread().getName());
		
	}

}
