package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.model.UserModel;

public class UserDBConnection {
	
	public UserModel fetchUserDetails(String userName) {
		UserModel userModel = new UserModel();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select  user_name,user_pass from login_tbl where user_name='"+userName+"'");
			
			
			while(rs.next()) {
				userModel.setUserName(rs.getString(1));
				userModel.setUserPass(rs.getString(2));
				
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userModel;
	}

}
