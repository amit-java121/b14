package com;

public class TestAbstract extends Test{

	@Override
	public void m1() {

		
		System.out.println("m1:::");
	}
	
	
	public static void main(String[] args) {
		TestAbstract ta = new TestAbstract();	
	}

}
