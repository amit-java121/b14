package it;

import com.A;

public class TestProtected extends A{
	
	
	
	
	
	public static void main(String[] args) {
		TestProtected tp = new TestProtected();
		System.out.println(tp.str);
		tp.m1();
	}

}
