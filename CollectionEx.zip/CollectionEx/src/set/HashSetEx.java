package set;

import java.util.LinkedHashSet;

public class HashSetEx {
	
	public static void main(String[] args) {
		
		//HashSet<String> set = new HashSet<>();
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
		linkedHashSet.add("pqr");
		linkedHashSet.add("abc");
		linkedHashSet.add("abc");
		linkedHashSet.add("abc1");
		linkedHashSet.add("abc2");
		
		//set.clear();
		System.out.println(linkedHashSet);
		
	}

}
