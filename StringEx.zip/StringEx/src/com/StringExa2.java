package com;

public class StringExa2 {
	
	
	public static void main(String[] args) {
		String str ="TEST is smothing";
		String str1 ="Test";
		
		//System.out.println(str.charAt(2));
		//System.out.println(str.compareToIgnoreCase(str1));
		
		//System.out.println(str.contains("t"));
		//System.out.println(str.contentEquals("test"));
		
		//System.out.println(str.replace('t', 'p'));
		//System.out.println(str.toLowerCase());
		//System.out.println(str.substring(2, 4));
		
//		String[] arr = str.split(" ");
//		
//		for(int i=0;i<arr.length;i++) {
//			System.out.println(arr[i]);
//		}
		
		//String str3 ="test";
		//String str4 =" test ";
		//System.out.println(str3.equals(str4.trim()));
		
		
		System.out.println("thread::: "+Thread.currentThread().getName());
	}

}
