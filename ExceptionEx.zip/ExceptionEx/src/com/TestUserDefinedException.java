package com;

public class TestUserDefinedException {
	
	public void testException(String username) throws UserNotFoundException {
		
		
		if(username.equalsIgnoreCase("rohan")) {
		
		
			throw new UserNotFoundException(100,"this is present:::");
		}
	}
	
	
	public static void main(String[] args) {
		TestUserDefinedException td = new TestUserDefinedException();
		
		
		try {
			td.testException("rohan");
		} catch (UserNotFoundException e) {
			System.out.println(e.exceptionCode);
			System.out.println(e.exceptionMessage);
		}
		
	}

}
