package com;

public class Customer {
	
	public void saveCustomer(int a) {
		System.out.println("save customer logic:::");
		
	}
	
	public void deleteCustomer() {
		System.out.println("delete customer method::");
	}

}
