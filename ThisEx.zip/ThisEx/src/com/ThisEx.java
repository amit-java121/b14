package com;

public class ThisEx {
	
	public static void main(String[] args) {
		Customer customer = new Customer(10001,"abc","pune");
		
		
		System.out.println(customer.toString());
		
	}

}
