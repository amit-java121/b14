package com.it.dao;

import com.it.model.UserModel;

public interface ILoginUserDao {

	UserModel getUserDetails(String username);

}
