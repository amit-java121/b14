package transaction;

public class Job extends Thread{
	
	PrintNumber pn;
	
	public Job(PrintNumber pn) {
		this.pn = pn;
	}
	
	@Override
	public void run() {
		pn.print();
	}

}
