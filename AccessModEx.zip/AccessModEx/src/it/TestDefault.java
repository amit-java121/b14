package it;

public class TestDefault {
	
	int aa =10;
	
	void m1() {
		System.out.println("m1 called::");
	}
	
	//TestDefault(){}

}
