package it;

import com.A;

public class Test {
	
	public static void main(String[] args) {
		TestDefault tde = new TestDefault();
		tde.m1();

	}

}
