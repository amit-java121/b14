package com;

public class A {
	int a=10;
	String name="Amit";
	
	
	public String userName() {
		return "Hi Akshya";
	}

}
