package com;

public class MethodsExa {
	
	
	public int add(int a,int b) {
		
		int c = a+b;
		
		//System.out.println("add: "+c);
		return c;
	}
	

//	public static void main(String[] args) {
//		MethodsExa m = new MethodsExa();
//		m.add(5, 5);
//	}

}
