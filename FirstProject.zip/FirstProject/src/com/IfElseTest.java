package com;

import java.util.Scanner;

public class IfElseTest {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String age = sc.nextLine();
		
		IfElseTest it = new IfElseTest();
		
		String msg = it.verifyAge(Integer.valueOf(age));
		System.out.println(msg);
		
	}
	
	
	public String verifyAge(int age) {
		
		String str ="";
		System.out.println("before logic");
		
		if(age > 20) {
			str = "You are eligiable for vote:::";
			//logic
			if(age > 60) {
				////
			}else {
				///
			}
			
		}else {
			str ="You are not eligiable for vote:::"+age+"";
		}
		
		return str;
	}

}
