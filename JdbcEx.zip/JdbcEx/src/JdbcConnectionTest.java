import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class JdbcConnectionTest {

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("setp 1");

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			System.out.println("step 2");

			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from user");
			System.out.println("step 4");
			while (rs.next()) {
				System.out.println(rs.getString("id"));
				System.out.println(rs.getString("user_name"));
				System.out.println(rs.getString("address"));
				System.out.println(rs.getString("mobile"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	//
	
	public List<User> getUserDetails() {
		
		List<User> list = new ArrayList<>();
		Connection con =  null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("setp 1");

			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			System.out.println("step 2");

			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from user");
			System.out.println("step 4");
			
			
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUserName(rs.getString("user_name"));
				user.setAddress(rs.getString("address"));
				user.setMobileNumber(Integer.valueOf(rs.getString("mobile")));
				
//				System.out.println(rs.getString("id"));
//				System.out.println(rs.getString("user_name"));
//				System.out.println(rs.getString("address"));
//				System.out.println(rs.getString("mobile"));
				list.add(user);
			}
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}

}
