import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class TestPayment {
	
	public static void main(String[] args) throws Exception {
		
		Payment payment = new Payment(1000, 1515151515, 1511, "test",null);
		
		FileOutputStream fos = new FileOutputStream("C:\\Users\\Amit\\Desktop\\payment.txt");
		
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(payment);
		
		oos.flush();
		oos.close();
		
	}

}
