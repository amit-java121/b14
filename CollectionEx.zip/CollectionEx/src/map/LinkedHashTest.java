package map;

import java.util.LinkedHashMap;

public class LinkedHashTest {
	
	public static void main(String[] args) {
		
		LinkedHashMap<Integer, String> linkedhashmap = new LinkedHashMap<Integer, String>();
		
		linkedhashmap.put(101, "rohan");
		linkedhashmap.put(102, "prashant");
		linkedhashmap.put(102, "Akshya");
		linkedhashmap.put(104, "rohan");
		linkedhashmap.put(null, null);
		linkedhashmap.put(105, null);
		
		System.out.println(linkedhashmap.toString());
	}

}
