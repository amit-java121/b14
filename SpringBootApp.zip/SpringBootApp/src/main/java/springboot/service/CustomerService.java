package springboot.service;

import springboot.model.Customer;

public interface CustomerService {

	Customer verifyCustomerCredentials(String username, String passowrd);

}
