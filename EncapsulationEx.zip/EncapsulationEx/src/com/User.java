package com;

public class User {
	private int userid;
	private String userName;
	private String address;	
	
	public int getUserid() {
		return userid;
	}
	public String getUserName() {
		return userName;
	}
	public String getAddress() {
		return address;
	}
	

	
	
	
}
