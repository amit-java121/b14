package multi;

public class B extends A{
	
	public void m2() {
		System.out.println("class B method m2() ");
	}


}
