package com;

public class A {
	
	public static void main(String[] args) {
		
		A a = new A();
		System.out.println(a);
		System.out.println(a.hashCode());
		
	}

}
