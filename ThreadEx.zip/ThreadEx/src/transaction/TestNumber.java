package transaction;

public class TestNumber {
	
	public static void main(String[] args) {
		
		PrintNumber pn = new PrintNumber();
		
		Job job = new Job(pn);
		job.start();
		
		Job1 job1 = new Job1(pn);
		 job1.start();
		
		
	}

}
