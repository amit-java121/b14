package springboot.service;

import springboot.model.Customer;

public interface CustomerService {

	Customer verifyCustomerCredentials(String username, String passowrd);

	Customer saveCustomer(Customer customer);

	Customer getCustomerDataById(Integer id);

	boolean deleteCustomerDataById(Integer id);

	void updateCustomerDetails(Customer customer);

}
