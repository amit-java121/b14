package com.orenda.model;


public class Admin {
	
}
