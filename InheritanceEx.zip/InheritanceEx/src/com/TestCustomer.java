package com;

public class TestCustomer {
	
	public static void main(String[] args) {
		
//		Customer customer = new Customer(1001, "Akshya", "Pune");
//		System.out.println(customer.getCutomerID());
		
		
			//NewCustomer newCustomer = new NewCustomer(1003, "xyz", "pune",123616);
			
		NewCustomer  newCustomer = new NewCustomer();
		
		newCustomer.setCustomerName("amit");
		newCustomer.setCutomerID(101001);
		newCustomer.setCustomerAddress("pune");
		
		newCustomer.setAdhaarNumber(199191991);
			//System.out.println(newCustomer.getAdhaarNumber());
			

	}

}
