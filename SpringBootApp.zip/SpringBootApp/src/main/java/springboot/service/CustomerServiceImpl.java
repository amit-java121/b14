package springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springboot.dao.CustomerRepository;
import springboot.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerRepository repository;

	@Override
	public Customer verifyCustomerCredentials(String username, String passowrd) {
		
		Customer customer = repository.findUserByEmail(username);
		return customer;
	}

	@Override
	public Customer saveCustomer(Customer customer) {

		Customer cust = repository.save(customer);
		
		return cust;
	}

	@Override
	public Customer getCustomerDataById(Integer id) {
		
		Customer customer = repository.getById(id);
		return customer;
	}

	@Override
	public boolean deleteCustomerDataById(Integer id) {
		boolean flag = false;
		try {
			repository.deleteById(id);
			flag =true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public void updateCustomerDetails(Customer customer) {
		
//		Customer cust = repository.getById(customer.getUserId());
//		
//		cust.setUserId(customer.getUserId());
//		cust.setUserName(customer.getUserName());
//		cust.setUserEmail(customer.getUserEmail());
//		cust.setMobileNumber(customer.getMobileNumber());
//		cust.setCountry(customer.getCountry());
		
		repository.save(customer);
		
		
	}

}
