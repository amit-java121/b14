package map;

import java.util.Hashtable;

public class HashTableEx {
	
	public static void main(String[] args) {
		Hashtable<Integer, String> hashtable = new Hashtable<>();
		hashtable.put(101, "rohan");
		hashtable.put(102, "rohan1");
		hashtable.put(103, null);
		
		System.out.println(hashtable);
	}

}
