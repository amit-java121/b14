package com.orenda.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;


import com.orenda.model.UserDetails;
import com.orenda.service.IClientService;

@Controller
public class ClientController {
	@Autowired
	IClientService clientService;
	//@GetMapping("/")
	public String client() {
		return "client";
	}
	@GetMapping("/Register")
	public String clientDetails(@ModelAttribute UserDetails client, @RequestParam("userLogin.Password") String userPass,
			Model model) {
		System.out.println("user data" + client.toString());
		System.out.println("inside of save");

		boolean flag = clientService.saveData(client, userPass);
		if (flag) {
			System.out.println("Save User Data");
			return "client";

		} else {
			System.out.println("Data Cant Save");
		}
		return "client";
	}

}
