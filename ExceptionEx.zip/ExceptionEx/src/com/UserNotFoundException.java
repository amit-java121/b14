package com;

public class UserNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	int exceptionCode;
	String exceptionMessage;
	
	
	public UserNotFoundException() {
		super();
	}
	
	public UserNotFoundException(int exceptionCode,String exceptionMessage) {
		super();
		this.exceptionCode = exceptionCode;
		this.exceptionMessage = exceptionMessage;
	}

}
