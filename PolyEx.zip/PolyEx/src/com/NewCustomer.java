package com;

public class NewCustomer extends Customer{
	
	public void saveCustomer() {
		System.out.println("save customer logic new class:::");
		
	}

}
