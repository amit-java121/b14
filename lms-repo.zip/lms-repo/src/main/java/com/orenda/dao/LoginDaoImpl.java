package com.orenda.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.orenda.model.UserDetails;
import com.orenda.model.UserLogin;

//@SuppressWarnings("deprecation")
@Repository
public class LoginDaoImpl implements ILoginDao {

	
	
	@Autowired
	SessionFactory sessionFactory;
	

	@Override
	public UserLogin verifyUser(String email) {
		Session session = sessionFactory.openSession();
		UserLogin userLogin = new UserLogin();
		Query query = session.createQuery("from UserLogin where email=:employeeEmail1");
		
	
		
		List user = query.setParameter("employeeEmail1", email).getResultList();
		System.out.println(user + "   mmmmmmmmmmmmmmm");
		if (user.size() > 0) {
			userLogin = (UserLogin) user.get(0);
		}

		return userLogin;
	}

	@Override
	public UserLogin savePassword(String b, String email) {
		System.out.println("inside of save dao");
		Session session = sessionFactory.getCurrentSession();
		UserLogin userlogin = new UserLogin();
		Query query = session.createQuery("update UserLogin set Password =:pass where email =:userEmail");
		query.setParameter("pass", b);
		query.setParameter("userEmail", email);
		query.executeUpdate();
		return userlogin;

	}

	public UserDetails getUserDetails(String email) {
		UserDetails userDetails = new UserDetails();
		Session session = sessionFactory.openSession();

		Query query = session.createQuery("from UserDetails where userEmail=:userEmail1");

		List userObject = query.setParameter("userEmail1", email).getResultList();

		if (userObject.size() > 0) {
			userDetails = (UserDetails) userObject.get(0);

		}

		return userDetails;

	}

	
	
}
