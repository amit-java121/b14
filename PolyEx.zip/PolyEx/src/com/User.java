package com;

public class User {
	
	public void add(int a,long b) {
		System.out.println("int ");
		
	}
	
	public void add(long a,int b) {
		System.out.println("long ");
	}
	
	public static void main(String[] args) {
		User user = new User();
		//user.add(10, 10); Ambiguity
		
	}

}
