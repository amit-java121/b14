package hiererichal;

public class B extends A{

	public void m2() {
		System.out.println("class B method m2() ");
	}
	
	public static void main(String[] args) {
		B b = new B();
		b.m1();
		b.m2();
	}
}
