package com;

public class StringTest {
	
	public static void main(String[] args) {
		
		String str ="hello";
		String str1 = "hello1";
		
		String str2 = new String("hello");
//		
//		System.out.println(str.equals(str1));
//		System.out.println(str == str1);
	
		
		
		String  st = str.concat(" world!");
		
		//System.out.println(str);
		
		//System.out.println(str2);
		
		//String str1 = new String("hello");
		
		
	}

}
