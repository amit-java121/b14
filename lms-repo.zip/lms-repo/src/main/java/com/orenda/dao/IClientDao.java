package com.orenda.dao;


import com.orenda.model.UserDetails;

public interface IClientDao {

	

	public boolean saveUserData(UserDetails client);

}
