
public class InstanceVariableEx {
	
	   int a =10; //instance
	   static int bb =20; //
	
	   
	   public void add() {
		   int cc =50; //local variable
		 System.out.println(cc);
		   System.out.println(cc+a);
		   
		   
	   }
	   
	   public void subtract() {
		   int cc =50; //local variable
		 System.out.println(cc);
		   System.out.println(cc-a);
		   
		   
	   }
	   
	   public static void add123() {
		   System.out.println("add123:::");
	   }
	   
	
	public static void main(String[] args) {
		InstanceVariableEx iv = new InstanceVariableEx();
		iv.add();
		iv.subtract();
		
		System.out.println(iv.a);
		System.out.println(InstanceVariableEx.bb);
		//iv.add123();
		InstanceVariableEx.add123();
		
		//System.out.println(add123());
	}

}
