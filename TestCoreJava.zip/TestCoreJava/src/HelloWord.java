
public class HelloWord {
	
	public static void main(String[] args) {
		System.out.println("hiii");
		
		HelloWord hw = new HelloWord();
		hw.add();
		hw.subtract();
	}
	
	public void add() {
		
		int sum = 5+10;
		System.out.println(sum);
	}
	
	public void subtract() {
		
		int sum = 10+10;
		System.out.println(sum);
	}

}
