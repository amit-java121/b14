package com;

public class TestPrivate {
	
	private String name = "Akshay";
	
	private void test() {
		System.out.println("test method called::");
	}
	
	private TestPrivate() {}
	
	
	public static void main(String[] args) {
		TestPrivate test = new TestPrivate();
	}
	
}
