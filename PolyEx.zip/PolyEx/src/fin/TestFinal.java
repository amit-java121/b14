package fin;

public class TestFinal {
	
	 static final int aa;
	
	 
	 static {
		 aa =1010;
	 }
	
	 
	public void test() {
		
		//aa =1000;
		System.out.println(aa);
	}
	

}
