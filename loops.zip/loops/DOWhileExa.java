package loops;

public class DOWhileExa {
	
	public static void main(String[] args) {
		
		int a=9;
		
		do {
			
			System.out.println("do:::");
			a++;
			
		} while (a>=10);
	}

}
