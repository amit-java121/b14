package com.orenda.dao;


public interface IAdminDao {

}
