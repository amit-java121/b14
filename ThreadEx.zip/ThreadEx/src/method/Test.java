package method;

public class Test {
	
	public static void main(String[] args) throws InterruptedException {
		
		ThreadA th = new ThreadA();
		th.start();
		
		synchronized (th) {
			th.wait(1000);
		}
		
		System.out.println(th.sum);
	
	}

}
