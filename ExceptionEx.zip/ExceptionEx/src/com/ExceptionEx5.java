package com;

public class ExceptionEx5 {
	
	public int division(int a,int b) {
		int c=0;
		
		System.out.println("before division::");
			try {
				
				int[] arr = new int[2];
				arr[0]=10;
				arr[1]=20;
				for(int i=0;i<arr.length;i++) {
					System.out.println(arr[i+1]);
				}
				
				c = a / b;
			}catch(ArithmeticException e) {
				System.out.println("Exception ex:::");
			}catch(Exception ae) {
				ae.printStackTrace();
				//System.out.println("");
			}
			
			
		return c;
		
	}
	
	
	public static void main(String[] args) {
		ExceptionEx5 ee = new ExceptionEx5();
		ee.division(10, 0);
	}

}
