package sup;

public class SuperTest extends A{
	
	
	
	
	public SuperTest() {
		super();
		System.out.println("const:: SuperTest");
	}

	int age =30;
	
	public void test() {
		System.out.println(age);
		System.out.println(super.age);
		System.out.println(id);
		
		super.m1();
	}
	
	public void m1() {
		System.out.println("m1 of class SuperTest");
	}
	
	public static void main(String[] args) {
		SuperTest st = new SuperTest();
		st.test();
	}
}
