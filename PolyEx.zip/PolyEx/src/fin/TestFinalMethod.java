package fin;

public class TestFinalMethod {
	
	public final void m1() {
		System.out.println("m1 TestFinalMethod");
	}

}
