import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JdbcConnectionTest {

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("setp 1");

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			System.out.println("step 2");

			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from user");
			System.out.println("step 4");
			while (rs.next()) {
				System.out.println(rs.getString("id"));
				System.out.println(rs.getString("user_name"));
				System.out.println(rs.getString("address"));
				System.out.println(rs.getString("mobile"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	//
	
	public List<User> getUserDetails() {
		
		List<User> list = new ArrayList<>();
		Connection con =  null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("setp 1");

			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			System.out.println("step 2");

			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from user");
			System.out.println("step 4");
			
			
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUserName(rs.getString("user_name"));
				user.setAddress(rs.getString("address"));
				user.setMobileNumber(Integer.valueOf(rs.getString("mobile")));
				
//				System.out.println(rs.getString("id"));
//				System.out.println(rs.getString("user_name"));
//				System.out.println(rs.getString("address"));
//				System.out.println(rs.getString("mobile"));
				list.add(user);
			}
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}
	
	public void saveUserDetails(List<User> listOfUser) {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("setp 1");

		 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
		System.out.println("step 2");

		Statement stmt = con.createStatement();
		System.out.println("step 3");
		
		for(int i=0;i<listOfUser.size();i++) {
			User user = listOfUser.get(i);
			
		 int ii= stmt.executeUpdate("insert into user values("+user.getId()+",'"+user.getUserName()+"','"+user.getAddress()+"',"+user.getMobileNumber()+")");
		
		 System.out.println("step 4"+ii);
		}
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public void deleteUser(int id) {
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("setp 1");

			 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			System.out.println("step 2");

			Statement stmt = con.createStatement();
			System.out.println("step 3");
			
			int i= stmt.executeUpdate("delete from user where id="+id);
			System.out.println(i);
			
		}catch(Exception e) {
			
		}
	}
	
	//using prepared Statement
	
	public void saveUserDetailsUsingPsmt(List<User> listOfUser) {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("setp 1");

		 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
		System.out.println("step 2");

		PreparedStatement pstmt = con.prepareStatement("insert into user values(?,?,?,?)");
		
		for(int i=0; i < listOfUser.size(); i++) {
		 User user = listOfUser.get(i);
			
		pstmt.setInt(1, user.getId());
		pstmt.setString(2, user.getUserName());
		pstmt.setString(3, user.getAddress());
		pstmt.setInt(4, user.getMobileNumber());
		
		int index= pstmt.executeUpdate();
		System.out.println("i "+index);
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public User fetchUserById(int userId) {
		
		User user = new User();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("setp 1");

			 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			System.out.println("step 2");

			PreparedStatement pstmt = con.prepareStatement("select * from user where id=?");
			pstmt.setInt(1, userId);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				user.setId(rs.getInt(1));
				user.setUserName(rs.getString(2));
				user.setAddress(rs.getString(3));
				user.setMobileNumber(rs.getInt(4));
//				System.out.println(rs.getInt(1));
//				System.out.println(rs.getString(2));
//				System.out.println(rs.getString(3));
//				System.out.println(rs.getInt(4));
			}

			
			}catch(Exception e) {
				e.printStackTrace();
			}
		
		return user;
		
	}
	//Fetching data using Map 
	
	public Map<Integer,User> getUserAllDetails() {
		
		Map<Integer,User> map = new HashMap<>();
		
		Connection con =  null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("setp 1");

			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b14", "root", "root");
			System.out.println("step 2");

			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from user");
			System.out.println("step 4");
			
			
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUserName(rs.getString("user_name"));
				user.setAddress(rs.getString("address"));
				user.setMobileNumber(Integer.valueOf(rs.getString("mobile")));
				
				map.put(user.getId(), user);
			}
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return map;
		
	}

	

}
