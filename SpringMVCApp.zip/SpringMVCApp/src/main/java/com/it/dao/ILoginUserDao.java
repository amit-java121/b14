package com.it.dao;

import java.util.List;

import com.it.model.UserModel;

public interface ILoginUserDao {

	UserModel getUserDetails(String username);

	boolean saveUserDetail(UserModel userModel);
	
	public List<UserModel> getAllUserData();

}
