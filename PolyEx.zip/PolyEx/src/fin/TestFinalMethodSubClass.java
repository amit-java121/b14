package fin;

public class TestFinalMethodSubClass extends TestFinalMethod{

//	public void m1() {
//		System.out.println("m1 TestFinalMethodSubClass");
//	}
	
}
