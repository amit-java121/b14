package map;

import java.util.HashMap;

public class EmployeeTest {
	
	public HashMap<Integer, Employee> setEmployeeData() {
		Employee emp = new Employee(100, "rohan", "pune");
		Employee emp1 = new Employee(101, "rohan1", "mumbai");
		Employee emp2 = new Employee(102, "rohan2", "pune");
		Employee emp3 = new Employee(103, "rohan3", "nagpur");
		
		
		HashMap<Integer, Employee> map = new HashMap<Integer, Employee>();
		map.put(emp.getEmpId(), emp);
		map.put(emp1.getEmpId(), emp1);
		map.put(emp2.getEmpId(), emp2);
		map.put(emp3.getEmpId(), emp3);
		
		return map;
	}
	
	
	public static void main(String[] args) {
		
		EmployeeTest et = new EmployeeTest();
		HashMap<Integer, Employee> m = et.setEmployeeData();
		//System.out.println(m.get(102));
		Employee obj = m.get(102);

		System.out.println(obj);
		
	}

}
