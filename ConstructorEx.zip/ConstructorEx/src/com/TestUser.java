package com;

public class TestUser {
	
	
	public User setUserData() {
		//set data in user object 
		//User usr  = new User(1000,"amit","",1l,"");
		User usr = new User();
		usr.setUserID(1001);
		usr.setUserName("rohan");
		usr.setUserAddress("pune");
//		usr.setUserGender("male");
//		usr.setUserMob(101010100);
		
		return usr;
	}
	
	public static void main(String[] args) {
		
		
		TestUser tu = new TestUser();
	    User user = tu.setUserData();
	    
	    System.out.println(user.getUserID());
	    System.out.println(user.getUserName());
	    System.out.println(user.getUserAddress());
	    System.out.println(user.getUserGender());
	    System.out.println(user.getUserMob());
		
	}

}
