package com;

public class Job extends Thread{
	
	
	@Override
	public void run() {
		System.out.println("thread name: "+Thread.currentThread().getId());
		for(int i=10;i<20;i++) {
			System.out.println("job "+i);
			try {
				sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	

}
