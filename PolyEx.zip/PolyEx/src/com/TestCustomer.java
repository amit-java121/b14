package com;

public class TestCustomer {
	
	public static void main(String[] args) {
		
		NewCustomer newCustomer = new NewCustomer();
		newCustomer.saveCustomer();
		newCustomer.deleteCustomer();
	}

}
