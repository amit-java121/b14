
public class DataTypesEx {
	
	static boolean flag;
	static int aa;
	static long l;
	static float f;
	
	public static void main(String[] args) {
		
		System.out.println(flag);
		System.out.println(aa);
		System.out.println(l);
		System.out.println(f);
	}

}
