package com;

public class ThisConst {
	
	
//	public void test(ThisConst obj) {
//		System.out.println(obj);
//	}
	
	public ThisConst test1() {
		//test(this);
		return this;
	}
	
	public static void main(String[] args) {
		ThisConst tc = new ThisConst();
		ThisConst tt = tc.test1();
		System.out.println(tt);
	}

}
