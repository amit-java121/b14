package com;

public class ExceptionEx8 {
	
	public void testAge(int age) {
		
		if(age < 20) {
			
			throw new IllegalArgumentException(" u r not eligible for vote::");
			
		}else {
			
			System.out.println("success :::");
			
		}
		
	}
	
	
	public static void main(String[] args) {
		ExceptionEx8 ee = new ExceptionEx8();
		try {
		ee.testAge(18);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
