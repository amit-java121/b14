package com;

public class NewCustomer extends Customer{
	
	int adhaarNumber;

//	public NewCustomer(int cutomerID, String customerName, String customerAddress,int adhaarNumber) {
//		super(cutomerID, customerName, customerAddress);
//		this.adhaarNumber = adhaarNumber;
//	}
	
	
	
	public int getAdhaarNumber() {
		return adhaarNumber;
	}

	public void setAdhaarNumber(int adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}
	
	

}
