package com;

public class VariablesEx {

	
	int aa=10;
	static int bb =20;
	
	
	public void m1() {
		int cc =30;
		System.out.println(cc+aa);
		
	}
	
	public static void m2() {
		int dd =40;
		int sum = Test2.add(5, 5);
		System.out.println(dd+sum);
		int g =bb;
		System.out.println(bb);
	}
	
	public static void main(String[] args) {
		VariablesEx ve = new VariablesEx();
		m2();
		//Test t = new Test();
		System.out.println(Test.test);
		
		
	}
	

}
