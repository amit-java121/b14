package com.orenda.service;

import java.time.LocalDateTime;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.orenda.dao.IClientDao;


import com.orenda.model.UserDetails;
import com.orenda.model.UserLogin;

@Service
@Transactional
public class ClientServiceImpl implements IClientService {
@Autowired
IClientDao dao;
	
@Override
public boolean saveData(UserDetails client, String userPass) {
	
	UserLogin user = new UserLogin();
	String p = Base64.getEncoder().encodeToString(userPass.getBytes());

	user.setPassword(p);
	String y = client.getUserEmail();
	
	user.setEmail(y);
	client.setUserLogin(user);

	LocalDateTime date = LocalDateTime.now();
	client.setCreateDate(date);

	return dao.saveUserData(client);

}
	
	

}
