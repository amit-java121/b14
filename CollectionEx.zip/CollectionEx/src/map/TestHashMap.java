package map;

import java.util.HashMap;
import java.util.Map.Entry;

public class TestHashMap {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> hashmap = new HashMap<Integer, String>();
		
		hashmap.put(101, "rohan");
		hashmap.put(102, "prashant");
		hashmap.put(102, "Akshya");
		hashmap.put(104, "rohan");
		hashmap.put(null, null);
		hashmap.put(105, null);
		
		//System.out.println(hashmap.containsKey(104));
		//System.out.println(hashmap.get(104));
		//System.out.println(hashmap.putIfAbsent(106, "abababa"));
		
		//System.out.println(hashmap.remove(104));
		//System.out.println(hashmap.replace(101, "rohan", "pqr"));
		
		//System.out.println(hashmap.values());
		for(Entry<Integer, String> map:hashmap.entrySet()) {
			System.out.println("key: "+map.getKey()+" value: "+map.getValue());
		}
		
		
	}

}
