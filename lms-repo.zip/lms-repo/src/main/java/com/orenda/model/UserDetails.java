package com.orenda.model;

import java.time.LocalDateTime;
import java.util.Arrays;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="tbl_user_details")
public class UserDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="user_id")
	private int userId;
	@Column(name = "user_fname")
	private String userFame;
	@Column(name = "user_mname")
	private String userMname;
	@Column(name = "user_lname")
	private String userLname;
	@Column(name = "user_type")
	private String userType;
	@Column(name = "user_gender")
	private String Gender;
	@Column(name = "user_dob")
	private String Date;
	@Column(name = "user_prim_contact")
	private long userPrimContact;
	@Column(name = "user_alt_contact")
	private long userAltContact;
	@Column(name = "user_email")
	private String userEmail;
	@Column(name = "user_gov_id_number")
	private int userGovIdNumber;
	@Column(name = "user_gov_id_type")
	private String userGovIdType;
	@Column(name ="user_gov_id_image")
	private byte[] userGovImage;
	@Column(name="user_create_date")
	private LocalDateTime createDate;
	
	
	

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_cur_id")
	private Current_Address currentAddress;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_perm_id")
	private Permanent_Address permanentAddress;
	

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="login_id")
	private UserLogin  userLogin;
	
	
	
	public UserDetails() {
		// TODO Auto-generated constructor stub
	}

	

	public UserDetails(int userId, String userFame, String userMname, String userLname, String userType, String gender,
			String date, long userPrimContact, long userAltContact, String userEmail, int userGovIdNumber,
			String userGovIdType, byte[] userGovImage, LocalDateTime createDate, Current_Address currentAddress,
			Permanent_Address permanentAddress, UserLogin userLogin) {
		super();
		this.userId = userId;
		this.userFame = userFame;
		this.userMname = userMname;
		this.userLname = userLname;
		this.userType = userType;
		Gender = gender;
		Date = date;
		this.userPrimContact = userPrimContact;
		this.userAltContact = userAltContact;
		this.userEmail = userEmail;
		this.userGovIdNumber = userGovIdNumber;
		this.userGovIdType = userGovIdType;
		this.userGovImage = userGovImage;
		this.createDate = createDate;
		this.currentAddress = currentAddress;
		this.permanentAddress = permanentAddress;
		this.userLogin = userLogin;
	}



	public int getUserId() {
		return userId;
	}



	public void setUserId(int userId) {
		this.userId = userId;
	}



	public String getUserFame() {
		return userFame;
	}

	public void setUserFame(String userFame) {
		this.userFame = userFame;
	}

	public String getUserMname() {
		return userMname;
	}

	public void setUserMname(String userMname) {
		this.userMname = userMname;
	}

	public String getUserLname() {
		return userLname;
	}

	public void setUserLname(String userLname) {
		this.userLname = userLname;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public long getUserPrimContact() {
		return userPrimContact;
	}

	public void setUserPrimContact(long userPrimContact) {
		this.userPrimContact = userPrimContact;
	}

	public long getUserAltContact() {
		return userAltContact;
	}

	public void setUserAltContact(long userAltContact) {
		this.userAltContact = userAltContact;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public int getUserGovIdNumber() {
		return userGovIdNumber;
	}

	public void setUserGovIdNumber(int userGovIdNumber) {
		this.userGovIdNumber = userGovIdNumber;
	}

	public String getUserGovIdType() {
		return userGovIdType;
	}

	public void setUserGovIdType(String userGovIdType) {
		this.userGovIdType = userGovIdType;
	}

	public byte[] getUserGovImage() {
		return userGovImage;
	}

	public void setUserGovImage(byte[] userGovImage) {
		this.userGovImage = userGovImage;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	public UserLogin getUserLogin() {
		return userLogin;
	}

	public void setUserLogin(UserLogin userLogin) {
		this.userLogin = userLogin;
	}

	
	public Current_Address getCurrentAddress() {
		return currentAddress;
	}

	public void setCurrentAddress(Current_Address currentAddress) {
		this.currentAddress = currentAddress;
	}

	public Permanent_Address getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(Permanent_Address permanentAddress) {
		this.permanentAddress = permanentAddress;
	}





	

	
	
}
