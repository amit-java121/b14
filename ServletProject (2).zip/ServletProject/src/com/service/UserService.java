package com.service;

import com.db.UserDBConnection;
import com.model.UserModel;

public class UserService {
	
	public boolean verifyUserCredentials(String userName,String userPass) {
		
		//username/password from DB
		UserDBConnection udb = new UserDBConnection();
		UserModel userModel = udb.fetchUserDetails(userName);
		
		if(userName.equalsIgnoreCase(userModel.getUserName()) && userPass.equalsIgnoreCase(userModel.getUserPass())) {
			return true;
		}
		else {
			return false;
		}
		// validation
		//true/false-->return
		
		
	}

	public boolean saveUserDeatils(UserModel userModel) {
		UserDBConnection udb = new UserDBConnection();
		//boolean flag = udb.saveUserDeayisl(userModel);
		
		return udb.saveUserDeayisl(userModel);
	}
	

}
