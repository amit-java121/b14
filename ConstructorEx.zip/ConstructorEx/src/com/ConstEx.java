package com;

public class ConstEx {
	
	
	public ConstEx() {
		System.out.println("default const:::");
	}
	
	public ConstEx(int a) {
		this(10,20);
		System.out.println("param 1 const:::");
	}
		
	public ConstEx(int a,int b) {
		System.out.println("param 2 const:::");
	}

	
	public void print() {
		System.out.println("print method called::");
	}
	
	
	public static void main(String[] args) {
		//ConstEx ce12 = new ConstEx();
		ConstEx ce = new ConstEx(10);
		
		ce.print();
		
	}

}
