import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestAddress {
	
	public static void main(String[] args) throws Exception{
		
//		Address address = new Address(121, "annexe", "pune");
//		Payment payment = new Payment(1000, 1515151515, 1511, "test",address);
//		
//		FileOutputStream fos = new FileOutputStream("C:\\Users\\Amit\\Desktop\\payment.txt");
//		
//		ObjectOutputStream oos = new ObjectOutputStream(fos);
//		
//		oos.writeObject(payment);
//		
//		oos.flush();
//		oos.close();
		
		//read
		
		FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\payment.txt");
		
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Payment payment = (Payment)ois.readObject();
		ois.close();
		System.out.println(payment.getAddress().getFlatNo());
		System.out.println(payment.getAddress().getCity());
		
		
	}

}
