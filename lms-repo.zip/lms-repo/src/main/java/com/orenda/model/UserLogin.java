package com.orenda.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_login")
public class UserLogin {
	
	@Id
	@GeneratedValue(strategy =  GenerationType.AUTO)
	@Column(name="login_id")
	private int loginId;
	@Column(name = "user_password")
	private String Password;
	@Column(name = "user_email")
	private String email;
	
	@OneToOne(mappedBy = "userLogin")
	private UserDetails userDetails;
	public UserLogin() {
		// TODO Auto-generated constructor stub
	}
	public UserLogin(int loginId, String password, String email, UserDetails userDetails) {
		super();
		this.loginId = loginId;
		this.Password = password;
		this.email = email;
		this.userDetails = userDetails;
	}
	public int getLoginId() {
		return loginId;
	}
	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public UserDetails getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	
		
	
	
 
	
}