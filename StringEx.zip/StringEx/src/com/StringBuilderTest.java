package com;

import java.util.StringTokenizer;

public class StringBuilderTest {
	
	public static void main(String[] args) {
		
		//StringBuilder sb = new StringBuilder();
		
		StringTokenizer st = new StringTokenizer("this,is,my,name",",");
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		
	}

}
