package com.orenda.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="tbl_address_current")
public class Current_Address {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="address_cur_id")
	private int addressCurId;
	@Column(name = "address")
	private String address;
	@Column(name = "add_area")
	private String addArea;
	@Column(name = "landmark")
	private String landmark;
	@Column(name = "state")
	private String state;
	@Column(name = "district")
	private String district;
	@Column(name = "tahsil")
	private String tahsil;
	@Column(name = "village")
	private String village;
	@Column(name = "pincode")
	private String pincode;
	
	@OneToOne(mappedBy = "currentAddress")
	private UserDetails userDetails;
	
	public Current_Address() {
		// TODO Auto-generated constructor stub
	}


	public Current_Address(int addressCurId, String address, String addArea, String landmark, String state,
			String district, String tahsil, String village, String pincode, UserDetails userDetails) {
		super();
		this.addressCurId = addressCurId;
		this.address = address;
		this.addArea = addArea;
		this.landmark = landmark;
		this.state = state;
		this.district = district;
		this.tahsil = tahsil;
		this.village = village;
		this.pincode = pincode;
		this.userDetails = userDetails;
	}





	public int getAddressCurId() {
		return addressCurId;
	}

	public void setAddressCurId(int addressCurId) {
		this.addressCurId = addressCurId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddArea() {
		return addArea;
	}

	public void setAddArea(String addArea) {
		this.addArea = addArea;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getTahsil() {
		return tahsil;
	}

	public void setTahsil(String tahsil) {
		this.tahsil = tahsil;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}






	
	
	
	
	

}
