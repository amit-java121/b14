package com;

import java.util.ArrayList;

public class ArrayListtest {
	
	
	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<>();
		list.add("prashant");
		list.add("Akshya");
		list.add("rohan");
		list.add("abc");
		list.add("xyz");
		
		ArrayList<String> list2 = new ArrayList<>();
		
		list2.add("abc");
		list2.add("xyz");
		list2.add("pqr");
		list.addAll(0,list2);
		
		
		//System.out.println(list.contains("ABC"));
		
		//System.out.println(list.containsAll(list2));
		//System.out.println(list.get(2));
		//System.out.println(list.indexOf("prashant"));
		//System.out.println(list.isEmpty());
		//System.out.println(list.lastIndexOf("abc"));
		
		//System.out.println(list.remove("abc"));
		//System.out.println(list.set(0, "pqr"));
		//list.retainAll(list2);
		//System.out.println(list);
		
		System.out.println(list.subList(2, 6));
		//System.out.println(list);
		
	}

}
