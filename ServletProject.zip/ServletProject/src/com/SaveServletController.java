package com;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.UserModel;
import com.service.UserService;

/**
 * Servlet implementation class SaveServletController
 */
@WebServlet("/SaveServletController")
public class SaveServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveServletController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		UserModel userModel = new UserModel();
		
		userModel.setUserName(request.getParameter("userName"));
		userModel.setUserPass(request.getParameter("password"));
		userModel.setUserEmail(request.getParameter("userEmail"));
		userModel.setMobileNo(Long.valueOf(request.getParameter("userMBNumber")));
		userModel.setGender(request.getParameter("gender"));
		userModel.setCountry(request.getParameter("country"));
		
		
		UserService userService = new UserService();
		boolean flag = userService.saveUserDeatils(userModel);
		if(flag) {
			//logic 
			List<UserModel> listOfUsers = userService.getUserDetails();
			
			request.setAttribute("list", listOfUsers);
			RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
			rd.forward(request, response);
			
			System.out.println("saved successfully::::::::::;");
		}else {
			System.out.println("Not saved ::::::::::;");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
