package com;

import java.util.ArrayList;
import java.util.Iterator;

public class TestList {
	
	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("amit");
		list.add("rohan");
		list.add("prashant");
		list.add("Akshya");
		list.add(null);
		//list.add(200);
		
		
		////
		
		System.out.println(list.size());
		
		for (Object object : list) {
			 String name = (String) object;
			System.out.println(name);
			//System.out.println(object);
		}
		
//		Iterator itr = list.iterator();
//		
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
		
		
	}

}
