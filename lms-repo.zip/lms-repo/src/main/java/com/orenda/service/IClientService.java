package com.orenda.service;

import com.orenda.model.UserDetails;

public interface IClientService {

	
	
	public boolean saveData(UserDetails client, String userPass);

}
