package xpert;

public class B {
	
	public static void main(String[] args) {
		
		
		A a = new A();
		int sum = a.add();
		
		System.out.println(sum);
		
	}

}
