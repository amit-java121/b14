package com;

public class Test {
	
	static int test =50;
	
	public static void main(String[] args) {
		
		System.out.println("hi::: ");
		Test t = new Test();
		int sum= t.add(5,5);
		System.out.println("sum: "+sum);
	}
	
	
	public int add(int a,int b) {
		int c =a+b;
		return c;
	}

}
